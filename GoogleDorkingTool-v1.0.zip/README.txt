=================================
GOOGLE DORKING TOOL - VERSION 1.0
=================================

Thank you for downloading the Google Dorking Tool! This application allows you to perform advanced Google searches using specialized search operators (Google dorks) to find specific information.

-----------------
INSTALLATION
-----------------

1. Run "install.bat" to install the application
2. The installer will:
   - Copy the application to your Documents folder
   - Create a launcher on your desktop
   - Create an uninstaller

-----------------
FEATURES
-----------------

TWO OPERATING MODES:
- Manual Dorking: Create custom search queries using Google dork operators
- Auto Dorking: Automatically generate and run multiple dork queries based on a target

AUTO DORKING CATEGORIES:
- Basic Information
- Sensitive Files
- Exposed Directories
- Login Pages
- Potential Vulnerabilities
- Technologies
- Social Media
- Email Addresses
- Subdomains
- Person Search (specialized for individuals)
- Profile Pages
- Images
- News Articles
- Academic/Publications

RESULTS MANAGEMENT:
- Table view with clickable links
- Pagination support
- Export to CSV, JSON, and TXT formats
- Copy URL functionality
- Open links directly in browser

ADDITIONAL FEATURES:
- Save and load search queries
- Pre-defined dork templates
- Comprehensive help section

-----------------
USAGE
-----------------

MANUAL DORKING:
1. Select "Manual Dorking" from the mode dropdown
2. Enter your search query or use the dork operators to build one
3. Click "Search" to execute the query
4. View results in the Results tab

AUTO DORKING:
1. Select "Auto Dorking" from the mode dropdown
2. Enter a target name or domain in the input field
3. Select which categories of dorks you want to generate
4. Click "Generate & Run Dorks"
5. The tool will show all generated dorks and run the first one
6. Use the "Run Next Dork" button to cycle through the remaining dorks

PERSON SEARCH EXAMPLE:
To search for information about a person:
1. Select "Auto Dorking" mode
2. Enter the person's full name (e.g., "John Smith")
3. Ensure person-specific categories are selected
4. Click "Generate & Run Dorks"

-----------------
UNINSTALLATION
-----------------

To uninstall:
1. Go to Documents\Google Dorking Tool
2. Run "uninstall.bat"

-----------------
DISCLAIMER
-----------------

This tool is meant for educational purposes and legitimate security testing only. The developers are not responsible for any misuse or damage caused by this tool. Always obtain proper authorization before performing security tests on systems you do not own.

-----------------
SUPPORT
-----------------

If you encounter any issues or have questions, please contact the developer.
